#ifdef PHP_WIN32
#include "../../../../main/config.w32.h"
#else
#include <php_config.h>
#endif

#include "php.h"
#include <string.h>
#include "zend.h"
#include "zend_alloc.h"
